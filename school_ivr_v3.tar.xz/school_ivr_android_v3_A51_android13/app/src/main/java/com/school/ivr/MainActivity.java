package com.school.ivr;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private SettingsRepository settingsRepo;
    private Switch autoAnswer, speakerPrompt, dtmfListen;
    private EditText delay, welcome, fees, schedule, registration;
    private TextView status, device;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        settingsRepo = new SettingsRepository(this);
        bind(); load(); requestRuntimePermissions(); updateStatus();

        findViewById(R.id.btnDefaultDialer).setOnClickListener(v -> requestDialerRole());
        findViewById(R.id.btnAccessibility).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        findViewById(R.id.btnTest).setOnClickListener(v -> startActivity(new Intent(this, IvrTestActivity.class)));
        findViewById(R.id.btnDtmfLab).setOnClickListener(v -> startActivity(new Intent(this, DtmfLabActivity.class)));
        findViewById(R.id.btnSeedStudent).setOnClickListener(v -> {
            new StudentDbHelper(this).upsertStudent("1001", "طالب تجريبي", 60);
            Toast.makeText(this, "تمت إضافة الطالب التجريبي", Toast.LENGTH_SHORT).show();
        });
    }

    private void bind() {
        autoAnswer = findViewById(R.id.switchAutoAnswer);
        speakerPrompt = findViewById(R.id.switchSpeakerPrompt);
        dtmfListen = findViewById(R.id.switchDtmfListen);
        delay = findViewById(R.id.etDelay);
        welcome = findViewById(R.id.etWelcome);
        fees = findViewById(R.id.etFees);
        schedule = findViewById(R.id.etSchedule);
        registration = findViewById(R.id.etRegistration);
        status = findViewById(R.id.tvStatus);
        device = findViewById(R.id.tvDevice);
        device.setText(DeviceProfile.summary());
    }

    private void load() {
        autoAnswer.setChecked(settingsRepo.autoAnswer());
        speakerPrompt.setChecked(settingsRepo.experimentalSpeakerPrompt());
        dtmfListen.setChecked(settingsRepo.experimentalDtmfListen());
        delay.setText(String.valueOf(settingsRepo.answerDelaySeconds()));
        welcome.setText(settingsRepo.welcome());
        fees.setText(settingsRepo.fees());
        schedule.setText(settingsRepo.schedule());
        registration.setText(settingsRepo.registration());
    }

    private void save() {
        int d = 2;
        try { d = Integer.parseInt(delay.getText().toString().trim()); } catch (Exception ignored) { }
        d = Math.max(0, Math.min(20, d));
        settingsRepo.save(autoAnswer.isChecked(), speakerPrompt.isChecked(), dtmfListen.isChecked(), d,
                welcome.getText().toString().trim(), fees.getText().toString().trim(),
                schedule.getText().toString().trim(), registration.getText().toString().trim());
        Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> needed = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CALL_PHONE);
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_PHONE_STATE);
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO);
            if (Build.VERSION.SDK_INT >= 26 && checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ANSWER_PHONE_CALLS);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS);
            if (!needed.isEmpty()) requestPermissions(needed.toArray(new String[0]), 80);
        }
    }

    private void requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                if (rm.isRoleHeld(RoleManager.ROLE_DIALER)) Toast.makeText(this, "التطبيق هو تطبيق الاتصال الافتراضي بالفعل", Toast.LENGTH_SHORT).show();
                else startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 81);
            }
        } else {
            TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
            Intent i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
            startActivityForResult(i, 81);
        }
    }

    private boolean isDefaultDialer() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_DIALER);
        }
        TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
        return tm != null && getPackageName().equals(tm.getDefaultDialerPackage());
    }

    private void updateStatus() {
        status.setText("تطبيق الاتصال الافتراضي: " + (isDefaultDialer() ? "مفعّل ✓" : "غير مفعّل") +
                "\nملف الجهاز: " + (DeviceProfile.isTargetProfile() ? "A51 / Android 13 مطابق ✓" : "غير مطابق") +
                "\nخدمة إمكانية الوصول: " + (SchoolAccessibilityService.isConnected() ? "مفعلة ✓" : "غير مفعلة") +
                "\n\nV3 تختبر مسارين على جهازك: تشغيل الرسالة من مكبر الهاتف بعد الرد، والتقاط نغمات DTMF من الميكروفون. كلاهما تجريبي داخل مكالمة SIM لأن Android لا يعطي التطبيق العادي مسارًا مباشرًا لصوت المكالمة.");
    }

    @Override protected void onResume() { super.onResume(); if (status != null) updateStatus(); }
}
