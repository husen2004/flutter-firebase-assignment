package com.school.ivr;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import android.telecom.VideoProfile;

public class SchoolInCallService extends InCallService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TtsSpeaker tts;
    private MicDtmfMonitor dtmfMonitor;
    private IvrEngine ivr;
    private String activePhone = "غير معروف";

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        CallController.set(call);
        activePhone = getNumber(call);
        StudentDbHelper db = new StudentDbHelper(this);
        db.logCall(activePhone, "ADDED");
        if (DeviceProfile.isTargetProfile()) db.logCall(activePhone, "DEVICE_A51_ANDROID13");

        call.registerCallback(new Call.Callback() {
            @Override public void onStateChanged(Call c, int state) {
                if (state == Call.STATE_DISCONNECTED) {
                    stopExperimentalLayer();
                    CallController.clear(c);
                }
            }
        });

        Intent ui = new Intent(this, CallActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        ui.putExtra("phone", activePhone);
        try { startActivity(ui); } catch (Exception ignored) { }

        SettingsRepository settings = new SettingsRepository(this);
        if (settings.autoAnswer() && call.getState() == Call.STATE_RINGING) {
            handler.postDelayed(() -> {
                if (call.getState() == Call.STATE_RINGING) {
                    try {
                        call.answer(VideoProfile.STATE_AUDIO_ONLY);
                        db.logCall(activePhone, "AUTO_ANSWERED");
                        if (settings.experimentalSpeakerPrompt() || settings.experimentalDtmfListen()) {
                            handler.postDelayed(() -> startExperimentalLayer(settings), 900L);
                        }
                    } catch (Exception e) {
                        db.logCall(activePhone, "AUTO_ANSWER_FAILED");
                    }
                }
            }, settings.answerDelaySeconds() * 1000L);
        }
    }

    private void startExperimentalLayer(SettingsRepository settings) {
        StudentDbHelper db = new StudentDbHelper(this);
        try { setAudioRoute(CallAudioState.ROUTE_SPEAKER); } catch (Exception ignored) { }

        if (settings.experimentalSpeakerPrompt()) {
            try {
                if (tts != null) tts.shutdown();
                tts = new TtsSpeaker(this);
                ivr = new IvrEngine(this, text -> {
                    if (tts != null) tts.speak(text);
                });
                ivr.start();
                db.logCall(activePhone, "SPEAKER_IVR_STARTED");
            } catch (Exception e) {
                db.logCall(activePhone, "SPEAKER_IVR_FAILED");
            }
        }

        if (settings.experimentalDtmfListen()) {
            if (!SchoolAccessibilityService.isConnected()) {
                db.logCall(activePhone, "DTMF_ACCESSIBILITY_NOT_ENABLED");
                return;
            }
            dtmfMonitor = new MicDtmfMonitor();
            dtmfMonitor.start(new MicDtmfMonitor.Listener() {
                @Override public void onDigit(char digit) {
                    new StudentDbHelper(SchoolInCallService.this).logCall(activePhone, "DTMF_" + digit);
                    if (ivr != null) handler.post(() -> ivr.onDigit(digit));
                }
                @Override public void onState(String state) {
                    new StudentDbHelper(SchoolInCallService.this).logCall(activePhone, state);
                }
            });
        }
    }

    private void stopExperimentalLayer() {
        if (dtmfMonitor != null) { dtmfMonitor.stop(); dtmfMonitor = null; }
        if (tts != null) { tts.shutdown(); tts = null; }
        ivr = null;
    }

    @Override public void onCallRemoved(Call call) {
        stopExperimentalLayer();
        CallController.clear(call);
        super.onCallRemoved(call);
    }

    private String getNumber(Call call) {
        try {
            Uri h = call.getDetails().getHandle();
            return h == null ? "غير معروف" : h.getSchemeSpecificPart();
        } catch (Exception e) { return "غير معروف"; }
    }
}
