package com.school.ivr;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class DtmfLabActivity extends Activity {
    private MicDtmfMonitor monitor;
    private TextView state, digit;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dtmf_lab);
        state = findViewById(R.id.tvDtmfState);
        digit = findViewById(R.id.tvDtmfDigit);
        findViewById(R.id.btnDtmfStart).setOnClickListener(v -> startMonitor());
        findViewById(R.id.btnDtmfStop).setOnClickListener(v -> stopMonitor());
    }

    private void startMonitor() {
        stopMonitor();
        monitor = new MicDtmfMonitor();
        monitor.start(new MicDtmfMonitor.Listener() {
            @Override public void onDigit(char d) { runOnUiThread(() -> digit.setText(String.valueOf(d))); }
            @Override public void onState(String s) { runOnUiThread(() -> state.setText(s)); }
        });
    }

    private void stopMonitor() {
        if (monitor != null) { monitor.stop(); monitor = null; }
    }

    @Override protected void onDestroy() { stopMonitor(); super.onDestroy(); }
}
