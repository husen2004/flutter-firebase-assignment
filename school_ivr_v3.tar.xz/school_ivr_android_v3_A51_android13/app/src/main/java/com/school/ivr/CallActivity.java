package com.school.ivr;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class CallActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
        String phone = getIntent().getStringExtra("phone");
        ((TextView)findViewById(R.id.tvCaller)).setText(phone == null ? "مكالمة واردة" : "مكالمة من\n" + phone);
        findViewById(R.id.btnAnswer).setOnClickListener(v -> CallController.answer());
        findViewById(R.id.btnHangup).setOnClickListener(v -> { CallController.hangup(); finish(); });
    }
}
