package com.school.ivr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class StudentDbHelper extends SQLiteOpenHelper {
    public static class StudentBalance {
        public final String name;
        public final double balance;
        StudentBalance(String name, double balance) { this.name = name; this.balance = balance; }
    }

    public StudentDbHelper(Context context) { super(context, "school_local.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students (academic_no TEXT PRIMARY KEY, name TEXT NOT NULL, balance REAL NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE call_log (id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT, started_at INTEGER, state TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public void upsertStudent(String no, String name, double balance) {
        ContentValues v = new ContentValues();
        v.put("academic_no", no); v.put("name", name); v.put("balance", balance);
        getWritableDatabase().insertWithOnConflict("students", null, v, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public StudentBalance findBalance(String no) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT name,balance FROM students WHERE academic_no=?", new String[]{no})) {
            if (c.moveToFirst()) return new StudentBalance(c.getString(0), c.getDouble(1));
        }
        return null;
    }

    public void logCall(String phone, String state) {
        ContentValues v = new ContentValues();
        v.put("phone", phone); v.put("started_at", System.currentTimeMillis()); v.put("state", state);
        getWritableDatabase().insert("call_log", null, v);
    }
}
