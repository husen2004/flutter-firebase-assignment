package com.school.ivr;

import android.os.Build;

public final class DeviceProfile {
    private DeviceProfile() {}

    public static boolean isExactTargetModel() {
        String model = Build.MODEL == null ? "" : Build.MODEL.trim().toUpperCase();
        return model.equals("SM-A515F") || model.equals("SM-A515F/DSN") || model.contains("SM-A515F");
    }

    public static boolean isAndroid13() {
        return Build.VERSION.SDK_INT == 33;
    }

    public static boolean isTargetProfile() {
        return isExactTargetModel() && isAndroid13();
    }

    public static String summary() {
        return "الجهاز المستهدف: Samsung Galaxy A51 (SM-A515F/DSN)" +
                "\nالنظام المستهدف: Android 13 / One UI 5.1" +
                "\nالموجود فعليًا: " + Build.MANUFACTURER + " " + Build.MODEL +
                " / Android " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")" +
                "\nBuild: " + Build.DISPLAY +
                "\nالتطابق: " + (isTargetProfile() ? "مطابق ✓" : "غير مطابق");
    }
}
