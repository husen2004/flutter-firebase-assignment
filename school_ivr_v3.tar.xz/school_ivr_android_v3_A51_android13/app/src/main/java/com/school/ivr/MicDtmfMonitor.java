package com.school.ivr;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.SystemClock;

public class MicDtmfMonitor {
    public interface Listener {
        void onDigit(char digit);
        void onState(String state);
    }

    private static final int SAMPLE_RATE = 8000;
    private volatile boolean running;
    private Thread worker;
    private AudioRecord record;

    public void start(Listener listener) {
        if (running) return;
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            listener.onState("DTMF_BUFFER_ERROR");
            return;
        }
        int bufferBytes = Math.max(min * 4, 4096);
        try {
            record = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                listener.onState("DTMF_AUDIO_INIT_FAILED");
                release();
                return;
            }
            record.startRecording();
            running = true;
            listener.onState("DTMF_LISTENING");
        } catch (SecurityException se) {
            listener.onState("DTMF_PERMISSION_DENIED");
            release();
            return;
        } catch (Exception e) {
            listener.onState("DTMF_START_FAILED");
            release();
            return;
        }

        worker = new Thread(() -> loop(listener), "SchoolIVR-DTMF");
        worker.start();
    }

    private void loop(Listener listener) {
        short[] readBuf = new short[1024];
        short[] frame = new short[205]; // ~25.6ms at 8kHz
        int framePos = 0;
        char candidate = 0;
        int stable = 0;
        char lastEmitted = 0;
        long lastEmitAt = 0;

        while (running && record != null) {
            int n;
            try { n = record.read(readBuf, 0, readBuf.length); }
            catch (Exception e) { listener.onState("DTMF_READ_FAILED"); break; }
            if (n <= 0) continue;

            for (int i = 0; i < n; i++) {
                frame[framePos++] = readBuf[i];
                if (framePos == frame.length) {
                    char d = DtmfDetector.detect(frame, frame.length, SAMPLE_RATE);
                    framePos = 0;
                    if (d != 0 && d == candidate) stable++; else { candidate = d; stable = d == 0 ? 0 : 1; }
                    long now = SystemClock.elapsedRealtime();
                    if (candidate != 0 && stable >= 3 && (candidate != lastEmitted || now - lastEmitAt > 700)) {
                        lastEmitted = candidate;
                        lastEmitAt = now;
                        listener.onDigit(candidate);
                    }
                    if (d == 0 && now - lastEmitAt > 250) lastEmitted = 0;
                }
            }
        }
        listener.onState("DTMF_STOPPED");
    }

    public void stop() {
        running = false;
        try { if (record != null) record.stop(); } catch (Exception ignored) { }
        if (worker != null) {
            try { worker.join(250); } catch (InterruptedException ignored) { }
        }
        release();
    }

    private void release() {
        try { if (record != null) record.release(); } catch (Exception ignored) { }
        record = null;
        worker = null;
    }
}
