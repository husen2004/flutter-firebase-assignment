package com.school.ivr;

/** Lightweight Goertzel DTMF detector for 8 kHz mono PCM. */
public final class DtmfDetector {
    private static final int[] LOW = {697, 770, 852, 941};
    private static final int[] HIGH = {1209, 1336, 1477, 1633};
    private static final char[][] DIGITS = {
            {'1','2','3','A'},
            {'4','5','6','B'},
            {'7','8','9','C'},
            {'*','0','#','D'}
    };

    private DtmfDetector() { }

    public static char detect(short[] samples, int count, int sampleRate) {
        if (samples == null || count < 120) return 0;
        double total = 0;
        for (int i = 0; i < count; i++) {
            double s = samples[i] / 32768.0;
            total += s * s;
        }
        if (total / count < 0.00008) return 0;

        double[] lp = new double[4];
        double[] hp = new double[4];
        for (int i = 0; i < 4; i++) {
            lp[i] = goertzel(samples, count, sampleRate, LOW[i]);
            hp[i] = goertzel(samples, count, sampleRate, HIGH[i]);
        }
        int li = maxIndex(lp), hi = maxIndex(hp);
        double lmax = lp[li], hmax = hp[hi];
        double l2 = secondMax(lp, li), h2 = secondMax(hp, hi);

        // Require a clear peak in each DTMF group.
        if (lmax < 4.0 * l2 || hmax < 4.0 * h2) return 0;
        if (lmax < 0.003 || hmax < 0.003) return 0;

        double twist = lmax / hmax;
        if (twist < 0.08 || twist > 12.0) return 0;
        return DIGITS[li][hi];
    }

    private static double goertzel(short[] x, int n, int fs, int freq) {
        double k = 0.5 + ((double) n * freq / fs);
        double w = (2.0 * Math.PI / n) * k;
        double coeff = 2.0 * Math.cos(w);
        double q0, q1 = 0, q2 = 0;
        for (int i = 0; i < n; i++) {
            q0 = coeff * q1 - q2 + (x[i] / 32768.0);
            q2 = q1;
            q1 = q0;
        }
        return q1 * q1 + q2 * q2 - coeff * q1 * q2;
    }

    private static int maxIndex(double[] a) {
        int idx = 0;
        for (int i = 1; i < a.length; i++) if (a[i] > a[idx]) idx = i;
        return idx;
    }

    private static double secondMax(double[] a, int skip) {
        double m = 0;
        for (int i = 0; i < a.length; i++) if (i != skip && a[i] > m) m = a[i];
        return Math.max(m, 1e-9);
    }
}
