package com.school.ivr;

import android.content.Context;

public class IvrEngine {
    public interface Output { void speak(String text); }
    private enum State { MAIN, STUDENT_NUMBER }
    private final SettingsRepository settings;
    private final StudentDbHelper db;
    private final Output output;
    private State state = State.MAIN;
    private final StringBuilder digits = new StringBuilder();

    public IvrEngine(Context context, Output output) {
        this.settings = new SettingsRepository(context);
        this.db = new StudentDbHelper(context);
        this.output = output;
    }

    public void start() { state = State.MAIN; digits.setLength(0); output.speak(settings.welcome()); }

    public void onDigit(char d) {
        if (state == State.MAIN) {
            switch (d) {
                case '1': output.speak(settings.fees() + " لإعادة القائمة اضغط صفر."); break;
                case '2': output.speak(settings.schedule() + " لإعادة القائمة اضغط صفر."); break;
                case '3': output.speak(settings.registration() + " لإعادة القائمة اضغط صفر."); break;
                case '4':
                    state = State.STUDENT_NUMBER; digits.setLength(0);
                    output.speak("أدخل الرقم الأكاديمي للطالب ثم اضغط مربع.");
                    break;
                case '0': start(); break;
                default: output.speak("الخيار غير صحيح. " + settings.welcome());
            }
            return;
        }

        if (state == State.STUDENT_NUMBER) {
            if (d == '*') { digits.setLength(0); output.speak("تم مسح الرقم. أدخل الرقم الأكاديمي ثم اضغط مربع."); return; }
            if (d == '#') {
                String no = digits.toString();
                StudentDbHelper.StudentBalance s = db.findBalance(no);
                if (s == null) output.speak("لم يتم العثور على طالب بهذا الرقم. اضغط صفر للعودة للقائمة الرئيسية.");
                else output.speak("الطالب " + s.name + ". الرصيد المستحق " + formatBalance(s.balance) + " شيكل. اضغط صفر للعودة للقائمة الرئيسية.");
                state = State.MAIN; digits.setLength(0); return;
            }
            if (Character.isDigit(d) && digits.length() < 20) digits.append(d);
        }
    }

    private String formatBalance(double value) {
        long rounded = Math.round(value);
        if (Math.abs(value - rounded) < 0.001) return String.valueOf(rounded);
        return String.valueOf(value);
    }
}
