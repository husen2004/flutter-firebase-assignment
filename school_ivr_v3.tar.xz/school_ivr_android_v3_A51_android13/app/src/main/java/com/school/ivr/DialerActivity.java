package com.school.ivr;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.widget.EditText;
import android.widget.Toast;

public class DialerActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialer);
        EditText number = findViewById(R.id.etNumber);
        Uri data = getIntent().getData();
        if (data != null) number.setText(data.getSchemeSpecificPart());
        findViewById(R.id.btnCall).setOnClickListener(v -> {
            String n = number.getText().toString().trim();
            if (n.isEmpty()) return;
            try {
                TelecomManager tm = (TelecomManager)getSystemService(TELECOM_SERVICE);
                tm.placeCall(Uri.parse("tel:" + Uri.encode(n)), new Bundle());
            } catch (SecurityException e) {
                Toast.makeText(this, "اسمح بصلاحية إجراء المكالمات", Toast.LENGTH_LONG).show();
            }
        });
    }
}
