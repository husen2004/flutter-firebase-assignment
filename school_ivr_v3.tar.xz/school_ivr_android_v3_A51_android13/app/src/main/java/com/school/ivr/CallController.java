package com.school.ivr;

import android.telecom.Call;
import android.telecom.VideoProfile;

public final class CallController {
    private static Call current;
    private CallController() { }
    public static synchronized void set(Call call) { current = call; }
    public static synchronized Call get() { return current; }
    public static synchronized void clear(Call call) { if (current == call) current = null; }
    public static void answer() { Call c = get(); if (c != null) c.answer(VideoProfile.STATE_AUDIO_ONLY); }
    public static void hangup() { Call c = get(); if (c != null) c.disconnect(); }
}
