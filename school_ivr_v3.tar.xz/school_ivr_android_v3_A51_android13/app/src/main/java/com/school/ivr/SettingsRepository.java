package com.school.ivr;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsRepository {
    private final SharedPreferences p;
    public SettingsRepository(Context c) { p = c.getSharedPreferences("ivr_settings", Context.MODE_PRIVATE); }

    public boolean autoAnswer() { return p.getBoolean("auto_answer", true); }
    public boolean experimentalSpeakerPrompt() { return p.getBoolean("speaker_prompt", false); }
    public boolean experimentalDtmfListen() { return p.getBoolean("dtmf_listen", false); }
    public int answerDelaySeconds() { return Math.max(0, Math.min(20, p.getInt("delay", 2))); }
    public String welcome() { return p.getString("welcome", "مرحبًا بكم. للرسوم اضغط 1. للمواعيد اضغط 2. للتسجيل اضغط 3. للاستعلام عن رصيد طالب اضغط 4. لإعادة القائمة اضغط صفر."); }
    public String fees() { return p.getString("fees", "رسوم البرنامج ستون شيكل. يمكنك تعديل هذه الرسالة من شاشة الإعدادات."); }
    public String schedule() { return p.getString("schedule", "مواعيد الدوام قابلة للتعديل من شاشة الإعدادات."); }
    public String registration() { return p.getString("registration", "للتسجيل يرجى مراجعة إدارة المدرسة خلال ساعات الدوام."); }

    public void save(boolean auto, boolean speakerPrompt, boolean dtmfListen, int delay,
                     String welcome, String fees, String schedule, String registration) {
        p.edit().putBoolean("auto_answer", auto)
                .putBoolean("speaker_prompt", speakerPrompt)
                .putBoolean("dtmf_listen", dtmfListen)
                .putInt("delay", delay)
                .putString("welcome", welcome)
                .putString("fees", fees)
                .putString("schedule", schedule)
                .putString("registration", registration).apply();
    }
}
