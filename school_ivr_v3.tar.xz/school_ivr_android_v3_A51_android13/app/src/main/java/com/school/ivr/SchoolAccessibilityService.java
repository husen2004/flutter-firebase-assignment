package com.school.ivr;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * خدمة وصول محدودة جدًا: لا تقرأ محتوى الشاشة ولا تتعامل مع نقرات المستخدم.
 * وجودها مفعلة يساعد في اختبار التقاط الميكروفون أثناء مكالمة صوتية على Android.
 */
public class SchoolAccessibilityService extends AccessibilityService {
    private static volatile boolean connected = false;

    public static boolean isConnected() { return connected; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        connected = true;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(android.content.Intent intent) {
        connected = false;
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        connected = false;
        super.onDestroy();
    }
}
