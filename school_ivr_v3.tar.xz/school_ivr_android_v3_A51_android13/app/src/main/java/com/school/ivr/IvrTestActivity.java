package com.school.ivr;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

public class IvrTestActivity extends Activity {
    private TtsSpeaker speaker;
    private IvrEngine engine;
    private TextView prompt;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ivr_test);
        prompt = findViewById(R.id.tvPrompt);
        speaker = new TtsSpeaker(this);
        engine = new IvrEngine(this, this::say);

        GridLayout grid = findViewById(R.id.keypad);
        for (int i = 0; i < grid.getChildCount(); i++) {
            View v = grid.getChildAt(i);
            v.setOnClickListener(x -> {
                String tag = String.valueOf(x.getTag());
                if (!tag.isEmpty()) engine.onDigit(tag.charAt(0));
            });
        }
        findViewById(R.id.btnRestart).setOnClickListener(v -> engine.start());
        engine.start();
    }

    private void say(String text) { prompt.setText(text); speaker.speak(text); }
    @Override protected void onDestroy() { if (speaker != null) speaker.shutdown(); super.onDestroy(); }
}
