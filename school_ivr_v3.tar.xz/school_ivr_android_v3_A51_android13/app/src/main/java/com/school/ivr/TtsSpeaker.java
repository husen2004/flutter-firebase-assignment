package com.school.ivr;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class TtsSpeaker implements TextToSpeech.OnInitListener {
    private final TextToSpeech tts;
    private String pending;
    public TtsSpeaker(Context c) { tts = new TextToSpeech(c.getApplicationContext(), this); }
    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            Locale ar = new Locale("ar");
            tts.setLanguage(ar);
            tts.setSpeechRate(0.9f);
            if (pending != null) { speak(pending); pending = null; }
        }
    }
    public void speak(String text) {
        if (text == null) return;
        int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ivr_prompt");
        if (r == TextToSpeech.ERROR) pending = text;
    }
    public void shutdown() { tts.stop(); tts.shutdown(); }
}
