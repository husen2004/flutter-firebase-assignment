import 'package:flutter/material.dart';

class TableScreen extends StatelessWidget {
  const TableScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Table Screen'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Table(
          border: TableBorder.all(),
          defaultVerticalAlignment: TableCellVerticalAlignment.middle,
          children: const [
            TableRow(
              children: [
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('Name', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('Major', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('Level', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            TableRow(
              children: [
                Padding(padding: EdgeInsets.all(8), child: Text('Ahmed')),
                Padding(padding: EdgeInsets.all(8), child: Text('Computer Science')),
                Padding(padding: EdgeInsets.all(8), child: Text('3')),
              ],
            ),
            TableRow(
              children: [
                Padding(padding: EdgeInsets.all(8), child: Text('Sara')),
                Padding(padding: EdgeInsets.all(8), child: Text('Software Eng')),
                Padding(padding: EdgeInsets.all(8), child: Text('2')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
