import 'package:flutter/material.dart';
import 'table_screen.dart';

class ListScreen extends StatelessWidget {
  const ListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> items = [
      'Item 1: Flutter',
      'Item 2: Dart',
      'Item 3: Widgets',
      'Item 4: Navigator',
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('List Screen'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const TableScreen()),
                );
              },
              child: const Text('View Table'),
            ),
            const SizedBox(height: 12),

            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(
                      items[index],
                      style: const TextStyle(fontSize: 18),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
