package com.school.ivr;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_DIALER = 501;
    private static final int REQ_MIC = 502;

    private SettingsRepository settings;
    private EditText delay, welcome, fees, inquiries, secretary;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        settings = new SettingsRepository(this);
        bind();
        load();
        updateStatus();

        findViewById(R.id.btnEnable).setOnClickListener(v -> enableIvr());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        findViewById(R.id.btnTest).setOnClickListener(v -> startActivity(new Intent(this, IvrTestActivity.class)));
    }

    private void bind() {
        delay = findViewById(R.id.etDelay);
        welcome = findViewById(R.id.etWelcome);
        fees = findViewById(R.id.etFees);
        inquiries = findViewById(R.id.etInquiries);
        secretary = findViewById(R.id.etSecretary);
        status = findViewById(R.id.tvStatus);
    }

    private void load() {
        delay.setText(String.valueOf(settings.answerDelaySeconds()));
        welcome.setText(settings.welcome());
        fees.setText(settings.fees());
        inquiries.setText(settings.inquiries());
        secretary.setText(settings.secretaryPrompt());
    }

    private void save() {
        int d = 2;
        try { d = Integer.parseInt(delay.getText().toString().trim()); } catch (Exception ignored) { }
        d = Math.max(1, Math.min(10, d));
        settings.save(d,
                welcome.getText().toString().trim(),
                fees.getText().toString().trim(),
                inquiries.getText().toString().trim(),
                secretary.getText().toString().trim());
        Toast.makeText(this, "تم حفظ إعدادات الرد الآلي", Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void enableIvr() {
        save();
        if (!isDefaultDialer()) {
            requestDialerRole();
            return;
        }
        requestMicIfNeeded();
    }

    private void requestDialerRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), REQ_DIALER);
            }
        } else {
            TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
            Intent i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
            i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
            startActivityForResult(i, REQ_DIALER);
        }
    }

    private void requestMicIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        } else {
            Toast.makeText(this, "الرد الآلي مفعّل. جرّب الاتصال بهذا الهاتف من هاتف آخر.", Toast.LENGTH_LONG).show();
            updateStatus();
        }
    }

    private boolean isDefaultDialer() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_DIALER);
        }
        TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
        return tm != null && getPackageName().equals(tm.getDefaultDialerPackage());
    }

    private boolean hasMic() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateStatus() {
        status.setText("حالة النظام:\n" +
                "• تطبيق الهاتف الافتراضي: " + (isDefaultDialer() ? "مفعّل ✓" : "غير مفعّل") + "\n" +
                "• التقاط أزرار 1/2/3: " + (hasMic() ? "مفعّل ✓" : "يحتاج إذن الميكروفون بعد التفعيل") + "\n" +
                "• الرد التلقائي: بعد " + settings.answerDelaySeconds() + " ثانية\n\n" +
                "ملاحظة: هذه النسخة تستخدم مكبر الصوت والميكروفون كمسار تجريبي داخل مكالمة SIM. أندرويد العادي لا يتيح لتطبيق خارجي حقن التسجيل مباشرة في خط المكالمة.");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_DIALER) {
            if (isDefaultDialer()) requestMicIfNeeded();
            else Toast.makeText(this, "يلزم اختيار آفاق كتطبيق الهاتف الافتراضي لتشغيل الرد التلقائي.", Toast.LENGTH_LONG).show();
            updateStatus();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (hasMic()) Toast.makeText(this, "تم التفعيل. اتصل من هاتف آخر لاختبار 1 و2 و3.", Toast.LENGTH_LONG).show();
            else Toast.makeText(this, "الرد سيعمل، لكن التطبيق لن يستطيع التقاط أزرار المتصل بدون إذن الميكروفون.", Toast.LENGTH_LONG).show();
            updateStatus();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) updateStatus();
    }
}
