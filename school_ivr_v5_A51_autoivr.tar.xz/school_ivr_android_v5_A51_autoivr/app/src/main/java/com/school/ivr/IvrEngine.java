package com.school.ivr;

import android.content.Context;

public class IvrEngine {
    public interface Output {
        void speak(String text);
        void handoffToSecretary(String announcement);
    }

    private final SettingsRepository settings;
    private final Output output;

    public IvrEngine(Context context, Output output) {
        this.settings = new SettingsRepository(context);
        this.output = output;
    }

    public void start() { output.speak(settings.welcome()); }

    public void onDigit(char d) {
        switch (d) {
            case '1':
                output.speak(settings.fees() + " للعودة إلى القائمة الرئيسية اضغط صفر.");
                break;
            case '2':
                output.speak(settings.inquiries() + " للعودة إلى القائمة الرئيسية اضغط صفر.");
                break;
            case '3':
                output.handoffToSecretary(settings.secretaryPrompt());
                break;
            case '0':
                start();
                break;
            default:
                output.speak("الخيار غير صحيح. " + settings.welcome());
                break;
        }
    }
}
