package com.school.ivr;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;
import android.telecom.VideoProfile;

public class SchoolInCallService extends InCallService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TtsSpeaker tts;
    private MicDtmfMonitor dtmfMonitor;
    private IvrEngine ivr;
    private Call activeCall;
    private String activePhone = "غير معروف";
    private boolean handedToSecretary;

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        activeCall = call;
        handedToSecretary = false;
        CallController.set(call);
        activePhone = getNumber(call);
        StudentDbHelper db = new StudentDbHelper(this);
        db.logCall(activePhone, "CALL_ADDED");

        call.registerCallback(new Call.Callback() {
            @Override public void onStateChanged(Call c, int state) {
                if (state == Call.STATE_DISCONNECTED) {
                    stopIvrLayer();
                    CallController.clear(c);
                }
            }
        });

        Intent ui = new Intent(this, CallActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        ui.putExtra("phone", activePhone);
        try { startActivity(ui); } catch (Exception ignored) { }

        SettingsRepository settings = new SettingsRepository(this);
        if (settings.autoAnswer() && call.getState() == Call.STATE_RINGING) {
            handler.postDelayed(() -> autoAnswerAndStart(call, settings), settings.answerDelaySeconds() * 1000L);
        }
    }

    private void autoAnswerAndStart(Call call, SettingsRepository settings) {
        if (call.getState() != Call.STATE_RINGING) return;
        StudentDbHelper db = new StudentDbHelper(this);
        try {
            call.answer(VideoProfile.STATE_AUDIO_ONLY);
            db.logCall(activePhone, "AUTO_ANSWERED");
            handler.postDelayed(() -> startIvrLayer(settings), 1200L);
        } catch (Exception e) {
            db.logCall(activePhone, "AUTO_ANSWER_FAILED_" + e.getClass().getSimpleName());
        }
    }

    private void startIvrLayer(SettingsRepository settings) {
        if (activeCall == null || activeCall.getState() == Call.STATE_DISCONNECTED) return;
        handedToSecretary = false;
        StudentDbHelper db = new StudentDbHelper(this);

        try { setAudioRoute(CallAudioState.ROUTE_SPEAKER); } catch (Exception ignored) { }

        if (settings.speakerPrompt()) {
            try {
                if (tts != null) tts.shutdown();
                tts = new TtsSpeaker(this);
                ivr = new IvrEngine(this, new IvrEngine.Output() {
                    @Override public void speak(String text) {
                        if (!handedToSecretary && tts != null) tts.speak(text);
                    }

                    @Override public void handoffToSecretary(String announcement) {
                        handoffSecretary(announcement);
                    }
                });
                ivr.start();
                db.logCall(activePhone, "WELCOME_STARTED");
            } catch (Exception e) {
                db.logCall(activePhone, "WELCOME_FAILED");
            }
        }

        if (settings.dtmfListen()) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                db.logCall(activePhone, "DTMF_MIC_PERMISSION_MISSING");
                return;
            }
            dtmfMonitor = new MicDtmfMonitor();
            dtmfMonitor.start(new MicDtmfMonitor.Listener() {
                @Override public void onDigit(char digit) {
                    new StudentDbHelper(SchoolInCallService.this).logCall(activePhone, "DTMF_" + digit);
                    if (ivr != null && !handedToSecretary) handler.post(() -> ivr.onDigit(digit));
                }
                @Override public void onState(String state) {
                    new StudentDbHelper(SchoolInCallService.this).logCall(activePhone, state);
                }
            });
        }
    }

    private void handoffSecretary(String announcement) {
        if (handedToSecretary) return;
        handedToSecretary = true;
        if (dtmfMonitor != null) { dtmfMonitor.stop(); dtmfMonitor = null; }
        if (tts != null) tts.speak(announcement);
        new StudentDbHelper(this).logCall(activePhone, "SECRETARY_HANDOFF");
        handler.postDelayed(() -> {
            if (tts != null) { tts.shutdown(); tts = null; }
            ivr = null;
            try { setAudioRoute(CallAudioState.ROUTE_EARPIECE); } catch (Exception ignored) { }
        }, 4200L);
    }

    private void stopIvrLayer() {
        handedToSecretary = true;
        if (dtmfMonitor != null) { dtmfMonitor.stop(); dtmfMonitor = null; }
        if (tts != null) { tts.shutdown(); tts = null; }
        ivr = null;
        activeCall = null;
    }

    @Override public void onCallRemoved(Call call) {
        stopIvrLayer();
        CallController.clear(call);
        super.onCallRemoved(call);
    }

    private String getNumber(Call call) {
        try {
            Uri h = call.getDetails().getHandle();
            return h == null ? "غير معروف" : h.getSchemeSpecificPart();
        } catch (Exception e) { return "غير معروف"; }
    }
}
