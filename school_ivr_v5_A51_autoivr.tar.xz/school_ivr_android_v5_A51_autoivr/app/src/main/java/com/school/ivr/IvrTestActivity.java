package com.school.ivr;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class IvrTestActivity extends Activity {
    private TtsSpeaker tts;
    private IvrEngine ivr;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ivr_test);
        tts = new TtsSpeaker(this);
        TextView state = findViewById(R.id.tvPrompt);
        ivr = new IvrEngine(this, new IvrEngine.Output() {
            @Override public void speak(String text) {
                state.setText(text);
                tts.speak(text);
            }
            @Override public void handoffToSecretary(String announcement) {
                state.setText(announcement);
                tts.speak(announcement);
                Toast.makeText(IvrTestActivity.this, "تم تسليم المكالمة للسكرتير (اختبار)", Toast.LENGTH_LONG).show();
            }
        });

        ViewGroup keypad = findViewById(R.id.keypad);
        for (int i = 0; i < keypad.getChildCount(); i++) {
            View child = keypad.getChildAt(i);
            Object tag = child.getTag();
            if (tag == null) continue;
            child.setOnClickListener(v -> {
                String s = String.valueOf(v.getTag());
                if (!s.isEmpty()) ivr.onDigit(s.charAt(0));
            });
        }
        findViewById(R.id.btnRestart).setOnClickListener(v -> ivr.start());
        ivr.start();
    }

    @Override protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
