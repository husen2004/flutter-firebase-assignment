package com.school.ivr;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class IvrTestActivity extends Activity {
    private TtsSpeaker tts;
    private IvrEngine ivr;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ivr_test);
        tts = new TtsSpeaker(this);
        TextView state = findViewById(R.id.tvIvrState);
        ivr = new IvrEngine(this, new IvrEngine.Output() {
            @Override public void speak(String text) {
                state.setText(text);
                tts.speak(text);
            }
            @Override public void handoffToSecretary(String announcement) {
                state.setText(announcement);
                tts.speak(announcement);
                Toast.makeText(IvrTestActivity.this, "تم تسليم المكالمة للسكرتير (اختبار)", Toast.LENGTH_LONG).show();
            }
        });
        ivr.start();
        int[] ids = {R.id.b0,R.id.b1,R.id.b2,R.id.b3,R.id.b4,R.id.b5,R.id.b6,R.id.b7,R.id.b8,R.id.b9,R.id.bStar,R.id.bHash};
        char[] ds = {'0','1','2','3','4','5','6','7','8','9','*','#'};
        for (int i=0;i<ids.length;i++) {
            final char d=ds[i];
            findViewById(ids[i]).setOnClickListener(v -> ivr.onDigit(d));
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
