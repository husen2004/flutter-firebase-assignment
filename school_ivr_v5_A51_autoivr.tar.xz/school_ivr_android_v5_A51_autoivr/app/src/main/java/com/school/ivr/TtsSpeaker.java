package com.school.ivr;

import android.content.Context;
import android.media.AudioAttributes;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class TtsSpeaker implements TextToSpeech.OnInitListener {
    private final TextToSpeech tts;
    private String pending;
    private volatile boolean ready;

    public TtsSpeaker(Context c) {
        tts = new TextToSpeech(c.getApplicationContext(), this);
    }

    @Override public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            Locale ar = new Locale("ar");
            int result = tts.setLanguage(ar);
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            if (pending != null && ready) {
                String p = pending;
                pending = null;
                speak(p);
            }
        }
    }

    public void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (!ready) { pending = text; return; }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "afaq_ivr_prompt");
    }

    public void shutdown() {
        try { tts.stop(); } catch (Exception ignored) { }
        try { tts.shutdown(); } catch (Exception ignored) { }
    }
}
