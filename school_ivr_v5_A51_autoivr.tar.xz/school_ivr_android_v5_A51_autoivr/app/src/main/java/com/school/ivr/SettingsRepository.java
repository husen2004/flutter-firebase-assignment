package com.school.ivr;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsRepository {
    private final SharedPreferences p;
    public SettingsRepository(Context c) { p = c.getSharedPreferences("ivr_settings_v5", Context.MODE_PRIVATE); }

    public boolean autoAnswer() { return p.getBoolean("auto_answer", true); }
    public boolean speakerPrompt() { return p.getBoolean("speaker_prompt", true); }
    public boolean dtmfListen() { return p.getBoolean("dtmf_listen", true); }
    public int answerDelaySeconds() { return Math.max(1, Math.min(10, p.getInt("delay", 2))); }

    public String welcome() {
        return p.getString("welcome",
                "مرحبًا بكم في أكاديمية ومدرسة آفاق النموذجية. للرسوم اضغط الرقم واحد. للاستفسارات اضغط الرقم اثنين. للتحويل إلى السكرتير اضغط الرقم ثلاثة.");
    }
    public String fees() {
        return p.getString("fees", "للاستفسار عن الرسوم، يرجى مراجعة الإدارة أو تعديل رسالة الرسوم من داخل التطبيق.");
    }
    public String inquiries() {
        return p.getString("inquiries", "للاستفسارات العامة، يرجى متابعة تعليمات المدرسة أو الانتظار للتحدث مع السكرتير.");
    }
    public String secretaryPrompt() {
        return p.getString("secretary", "يرجى الانتظار. سيتم تحويل المكالمة إلى السكرتير على هذا الهاتف.");
    }

    public void save(int delay, String welcome, String fees, String inquiries, String secretary) {
        p.edit()
                .putBoolean("auto_answer", true)
                .putBoolean("speaker_prompt", true)
                .putBoolean("dtmf_listen", true)
                .putInt("delay", delay)
                .putString("welcome", welcome)
                .putString("fees", fees)
                .putString("inquiries", inquiries)
                .putString("secretary", secretary)
                .apply();
    }
}
